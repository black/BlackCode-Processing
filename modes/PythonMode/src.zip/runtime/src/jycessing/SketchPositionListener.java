package jycessing;

import java.awt.Point;

public interface SketchPositionListener {
  void sketchMoved(Point leftTop);
}
